import java.util.*;

public class StudDealer extends Dealer{

	public StudDealer(){
		super();
	}

	public StudDealer(String name){
		super(name);
		
	}


    public void startHands(){
    	// THe implementation: Finish in the future
    }
}
