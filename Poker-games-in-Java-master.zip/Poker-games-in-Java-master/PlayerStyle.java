abstract public class PlayerStyle
{
	abstract public void setBettingDegree(int degree);
	abstract public void setHandDegree(int degree);
	abstract public void setCallDegree(int degree);
	abstract public int getBettingDegree();
	abstract public int getHandDegree();
	abstract public int getCallDegree();
}